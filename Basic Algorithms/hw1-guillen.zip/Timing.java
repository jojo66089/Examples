/* file: Timing.java
 *	 Timing Utility: 
 *			We use System.nanoTime() here.
 *		A less accurate method is System.currentTimeMillis().
 *		See https://stackoverflow.com/questions/351565/system-currenttimemillis-vs-system-nanotime
 *
 *		We use fib(n) method to test.
 *
 * -- Chee Yap (Spring2024)
 * **************************************** */

public class Timing {

	/////////////////////////////////// METHODS:
	// sample method for tesing
	static int fib (int n){
		if (n <= 1) return n;
		return fib(n-1)+ fib(n-2);
	}

	// Timing:
	static double timing (int n){
		// time for fib(n) averaged over 3 times
		return timing(n, 3);
	}
	static double timing (int n, int m){
		// time for fib(n) averaged over m times
		int res;
		long start = System.nanoTime( ); 
			for (int i=0; i<m; i++)
			  	res = fib(n);
		long duration = System.nanoTime( ) - start; 
		double msec = duration/(m*1000000.0);
		return msec;
	}
	static String showTime (double msec){
		// msec is in milliseconds
		if (msec<1000)
				return String.format("%3.2f %s", msec, "millisecs");
		msec = msec/1000.0; // in seconds
		if (msec<60)
				return String.format("%2.2f %s", msec, "secs");
		msec = msec/60.0; // in minutes
		if (msec<60)
				return String.format("%2.2f %s", msec, "mins");
		msec = msec/60.0; // in hours
		if (msec<24)
				return String.format("%2.2f %s", msec, "hrs");
		msec = msec/24.0; // in days
		return String.format("%2.2f %s", msec, "hrs");
	}
	
	/////////////////////////////////// MAIN METHOD:
	public static void main (String [] args){
	  int ss = (args.length>0)? Integer.valueOf(args[0]) : 111;
	  int nn = (args.length>1)? Integer.valueOf(args[1]) : 10;
	  int mm = (args.length>2)? Integer.valueOf(args[2]) : 1;
	  int pp = (args.length>3)? Integer.valueOf(args[3]) : 3;

	  switch(mm){
	  case 0: 
		  	System.out.println("\n   ===> Case 0: timing");
	  	  	System.out.printf(
			"Time for fib(%d)=%d (average of 3 runs) is %s.\n",
		      	nn, fib(nn), showTime(timing(nn)));
			System.out.println("\n");
			break;
	  case 1:
		  	System.out.println("\n   ===> Case 1: 3 consecutive fib numbers");
			for (int i=-1; i<2; i++){
	  	  		System.out.printf("fib(%d)=%d\n",
		      			i+nn, fib(i+nn));
			}//for
			System.out.println("\n");
		 break;
		default:
		 	System.out.println("\n   ===> Default case: not implemented");
	  }//switch
	}//main
}//Timing
