/* file: Fib.java
 *
 * This version will fix the exponential time behavior 
 *		of Fib0.java, by using the technique of "memoization".
 *		This reduces two recursive calls to only one call.
 *	
 * Here is the idea:  declare an array of size 2,
 *				long[] pair = new long[2];
 * 		If
 *			(pair[0],pair[1]) = (fib(i-1), fib(i))
 *
 *		for any i>0, then you can easily transform its value to
 *			
 *			(pair[0],pair[1]) = (fib(i), fib(i+1))
 *
 *		Thus, after doing (n-1)  such transformations, you convert
 *					(fib(0),fib(1)) = (0,1)
 *			to
 *					(fib(n-1),fib(n)).
 *
 *	PLEASE IMPLEMENT THIS IDEA.
 *
 * 	Professor Yap
 *  Basic Algo
 * ************************************************** */

public class Fib extends
			Timing {

	// PLEASE IMPLEMENT ME! //
  
    
    public static long fibLin(long n){	
	if (n <= 1) return n; 
        
        long[] pair = {0, 1}; 
        for (long i = 2; i <= n; i++) {
            long next = pair[0] + pair[1];
            pair[0] = pair[1];
            pair[1] = next; 
        }
        return pair[1]; 
    }


	////////////////////////////////
	//	MAIN METHOD:
	////////////////////////////////
	public static void main (String [] args){
	  int ss = (args.length>0)? Integer.valueOf(args[0]) : 111;
	  int nn = (args.length>1)? Integer.valueOf(args[1]) : 10;
	  int mm = (args.length>2)? Integer.valueOf(args[2]) : 1;
	  int pp = (args.length>3)? Integer.valueOf(args[3]) : 3;

	  switch(mm){
	  case 0: 
		  	System.out.println("\n   ===> Case 0: timing");
	  	  	System.out.printf(
			"Time for fib(%d)=%d (average of 3 runs) is %s.\n",
		      	nn, fib(nn), showTime(timing(nn)));
			System.out.println("\n");
			break;
	  case 1:
		  	System.out.println("\n   ===> Case 1: 3 consecutive fib numbers");
			for (int i=-1; i<2; i++){
	  	  		System.out.printf("fib(%d)=%d\n",
		      			i+nn, fib(i+nn));
			}//for
			System.out.println("\n");
		 break;
		default:
		 	System.out.println("\n   ===> Default case: not implemented");
	  }//switch
	}//main
}//Fib
