/* file: Fib0.java
 *
 * This program computes F_n, the n-th Fibonacci number	where
 * 		F_n = n 					if n<=1,
 * 		F_n = F_{n-1} + F_{n-2}     if n>1.
 *
 * The number type in int. We want to explore the consequences of this.
 *
 * The program is wrong for moderately large value of n.
 * 	(1) Empirically, determine the first value of n where F_n is wrong?
 * 	(2) Analytically, determine this value of n; does it agree with (1)?
 *  (3) Efficiency issue: what is the largest value of F_n you can
 *		compute in 10 minutes?
 *
 * 	Professor Yap, Basic Algorithms
 * ************************************************** */

public class Fib0 extends
				Timing {

	// simple fibonacci method:
   public static long fibLin(long n){	
	if (n <= 1) return n; 
        
        long[] pair = {0, 1};
	 
        for (long i = 2; i <= n; i++) {
	    if (LONG.MAX_VALUE - pair[0] < pair[1]) {
                System.out.println("Overflow would occur at fib(" + i + ")");
                return -1;
	    }
            long next = pair[0] + pair[1];
            pair[0] = pair[1];
            pair[1] = next; 
        }
        return pair[1]; 
    }
	////////////////////////////////
	//	MAIN METHOD:
	////////////////////////////////
	public static void main (String [] args){
	  int ss = (args.length>0)? Integer.valueOf(args[0]) : 111;
	  long nn = (args.length>1)? Integer.valueOf(args[1]) : 10;
	  int mm = (args.length>2)? Integer.valueOf(args[2]) : 1;
	  int pp = (args.length>3)? Integer.valueOf(args[3]) : 3;

	  switch(mm){
	  case 0: 
		  	System.out.println("\n   ===> Case 0: timing");
	  	  	System.out.printf(
			"Time for fib(%d)=%d (average of 3 runs) is %s.\n",
		      	nn, fiblin(nn), showTime(timing(nn)));
			System.out.println("\n");
			break;
	  case 1:
		  	System.out.println("\n   ===> Case 1: 3 consecutive fib numbers");
			for (int i=-1; i<2; i++){
	  	  		System.out.printf("fib(%d)=%d\n",
		      			i+nn, fiblin(i+nn));
			}//for
			System.out.println("\n");
		 break;
		default:
		 	System.out.println("\n   ===> Default case: not implemented");
	  }//switch
	}//main
}//Fib0
