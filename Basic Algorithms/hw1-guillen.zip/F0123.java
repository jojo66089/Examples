public class F0123 extends Timing{

    static int f0(int n) {
        if (n == 0) return 1; 
        int result = 2; 
        for (int i = 1; i < n; i++) {
            int temp = 0;
            for (int j = 0; j < result; j++) {
                temp++; temp++;
            }
            result = temp;
        }
        return result;
    }

    static int f1(int n) {
        return n;
    }

    static int f2(int n) {
        if (n == 0) return 0;
        int result = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                result++; 
            }
        }
        return result;
    }

    static int f3(int n) {
        if (n == 0) return 0;
        int result = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    result++; 
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int nn = (args.length > 0) ? Integer.parseInt(args[0]) : 10;
        int mm = (args.length > 1) ? Integer.parseInt(args[1]) : 1;

        switch(mm) {
            case 0: 

		        System.out.println("\n   ===> Case 0:");
	  	  	System.out.printf(
			"Time for fib(%d)=%d (average of 3 runs) is %s.\n",
		      	nn, f0(nn), showTime(timing(nn)));
			System.out.println("\n");
		     
                break;
            case 1:
                System.out.println("\n   ===> Case 1: f1");
                System.out.println("f1(" + nn + ") = " + f1(nn) +  "total time :" + showTime(timing(nn)));
                break;
            case 2:
                System.out.println("\n   ===> Case 2: f2");
                System.out.println("f2(" + nn + ") = " + f2(nn) + " total time :" +  showTime(timing(nn)));
                break;
            case 3:
                System.out.println("\n   ===> Case 3: f3");
                System.out.println("f3(" + nn + ") = " + f3(nn ) +  " total time :" +  showTime(timing(nn)));
                break;
            default:
                System.out.println("\n   ===> Default case: not implemented");
        }
    }
}
