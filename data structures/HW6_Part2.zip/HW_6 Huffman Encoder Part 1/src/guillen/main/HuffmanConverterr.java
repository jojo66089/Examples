package guillen.main;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class HuffmanConverterr {
    // The # of chars in the ASCII table dictates
    // the size of the count[] & code[] arrays.
    public static final int NUMBER_OF_CHARACTERS = 256;
    // the contents of our message...
    private String contents;
    // the tree created from the msg
    private HuffmanTree huffmanTree;
    // tracks how often each character occurs
    private int count[];
    // the huffman code for each character
    private String code[];
    // stores the # of unique chars in contents
    private int uniqueChars = 0; // (optional)

    /** Constructor taking input String to be converted */
    public HuffmanConverterr(String input) {
        this.contents = input;
        this.count = new int[NUMBER_OF_CHARACTERS];
        this.code = new String[NUMBER_OF_CHARACTERS];
    }

    /**
     * Records the frequencies that each character of our message occurs... I.e., we
     * use 'contents' to fill up the count[] list...
     */
    public void recordFrequencies() {
        for (int i = 0; i < contents.length(); i++) {
            this.count[(int) contents.charAt(i)]++;
        }
        frequenciesToTree();
    }

    /**
     * Converts our frequency list into a Huffman Tree. We do this by
     * taking our count[] list of frequencies, and creating a binary
     * heap in a manner similar to how a heap was made in HuffmanTree's
     * fileToHeap method. Then, we print the heap, and make a call to
     * HuffmanTree.heapToTree() method to get our much desired
     * HuffmanTree object, which we store as huffmanTree.
     */
    public void frequenciesToTree() {
        ArrayList<HuffmanNode> arr = new ArrayList<HuffmanNode>();

        for (int i = 0; i < count.length; i++) {
            if (count[i] == 0) {
                // do nothing
            } else {
                HuffmanNode temp = new HuffmanNode("" + (char) i, count[i] + 0.0);
                arr.add(temp);
            }
        }

        HuffmanNode[] arr2 = new HuffmanNode[arr.size()];
        for (int i =0; i < arr.size(); i++) {
            arr2[i] = arr.get(i);
        }
        BinaryHeap<HuffmanNode> heap = new BinaryHeap<HuffmanNode>(arr2);
        heap.printHeap();
        huffmanTree = HuffmanTree.createFromHeap(heap);
        System.out.println();
        treeToCode();
    }
    
    public void treeToCode() {
        for(int i=0; i<256; i++) {
            code[i] = "";
        }
        treeToCode(huffmanTree.root, "");
    }


  
    private void treeToCode(HuffmanNode t, String s) {
        if (t.letter.length() > 1) {
            treeToCode(t.left, s + "0");
            treeToCode(t.right, s + "1");
        } else if (t.letter.length() == 1) {
            code[(int) t.letter.charAt(0)] = s;
        }
    }
  
    public String encodeMessage() {
        String output = "";
        for (int i = 0; i < contents.length(); i++) {
            output += code[(int) contents.charAt(i)];
        }
        return output;
    }
    public static String readContents(String filePath) {
        StringBuilder sb = new StringBuilder();
        try {
            Scanner scanner = new Scanner(new File(filePath));
            while (scanner.hasNextLine()) {
                sb.append(scanner.nextLine());
                sb.append("\n");
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

  
    public String decodeMessage(String code) {
        String output = "";
        HuffmanNode current = huffmanTree.root;
        for (int i = 0; i < code.length(); i++) {
            if (code.charAt(i) == '0') {
                current = current.left;
            } else if (code.charAt(i) == '1') {
                current = current.right;
            }
            if (current.letter.length() == 1) {
                output += current.letter;
                current = huffmanTree.root;
            }
        }
        return output;
    }
  

    	public static void main(String[] args) {
    	    String filePath = "/Users/joshuaguillen/eclipse-workspace/HW_6 Huffman Encoder Part 1/love_poem_80.txt";

    	    String input = readContents(filePath);

    	    HuffmanConverterr converter = new HuffmanConverterr(input);

    	    converter.recordFrequencies();

    	    String code = converter.encodeMessage();
    	    
    	    System.out.println("Huffman code: " + code);
    	    
    	    System.out.println("ASCII bits: " + input.length() * 8);
    	    
            System.out.println("Huffman bits: " + code.length());
            
            System.out.println();
            
            System.out.println(input);

    	
    }
}


