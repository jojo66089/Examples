package guillen.main;

import java.util.Scanner;

public class part1main {

	public static void main(String[] args) {
		System.out.println("Type in Legend: ");
		Scanner sc=new Scanner(System.in);
		String legend = sc.nextLine();
		BinaryHeap heap=HuffmanTree.legendToHeap(legend);
		heap.printHeap();
		HuffmanTree node=HuffmanTree.createFromHeap(heap);
		node.printLegend();
	}

}
