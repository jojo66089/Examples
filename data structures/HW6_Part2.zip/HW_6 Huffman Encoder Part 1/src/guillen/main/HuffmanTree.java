package guillen.main;

public class HuffmanTree{
	HuffmanNode root;
	public HuffmanTree(HuffmanNode huff) {
		this.root = huff;
		
	}
	public void printLegend() {
		printLegend(root, "");
		
		
	}
	private void printLegend(HuffmanNode t, String s) {
		if(t.letter.length() > 1) {
			printLegend(t.left, s + "0");
			printLegend(t.right, s + "1");
			
		}
		else{
			System.out.println(t.letter + " = " + s);
		}
		
		
	}
	public static BinaryHeap legendToHeap(String legend) {
		BinaryHeap heap = new BinaryHeap();
		String[] items = legend.split(" ");
		for(int i = 0; i < items.length; i += 2) {
			String letter = items[i];
			Double freq = Double.parseDouble(items[i+1]);
			heap.insert(new HuffmanNode(letter,freq));
		}
		return heap;
		
	}
	public static HuffmanTree createFromHeap(BinaryHeap b) {
		HuffmanTree tree;
		while(b.getSize() != 1) {
			HuffmanNode t1 = (HuffmanNode) b.deleteMin();
			HuffmanNode t2 = (HuffmanNode) b.deleteMin();
			
			HuffmanNode mergedHeap = new HuffmanNode(t1,t2);
			b.insert(mergedHeap);
			
			
		}
		tree = new HuffmanTree((HuffmanNode) b.findMin());
		
		return tree;
		
	}
}
